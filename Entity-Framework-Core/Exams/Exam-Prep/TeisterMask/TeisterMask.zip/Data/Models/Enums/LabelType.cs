﻿namespace TeisterMask.Data.Models
{
    public enum LabelType
    {
        Priority,
        CSharpAdvanced,
        JavaAdvanced,
        EntityFramework,
        Hibernate
    }
}