﻿namespace TeisterMask.Data.Models
{
    public enum LabelType
    {
        Priority = 10,
        CSharpAdvanced = 20,
        JavaAdvanced = 30,
        EntityFramework = 40,
        Hibernate = 50
    }
}