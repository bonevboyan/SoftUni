﻿namespace BasicWebServer.Server.HTTP
{
    public enum Method
    {
        Get = 1,
        Post = 2,
        Put = 3,
        Delete = 4
    }
}
