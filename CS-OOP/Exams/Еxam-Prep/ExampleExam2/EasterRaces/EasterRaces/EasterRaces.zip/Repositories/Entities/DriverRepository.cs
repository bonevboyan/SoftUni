﻿using EasterRaces.Models.Drivers.Contracts;
using EasterRaces.Models.Drivers.Entities;
using EasterRaces.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EasterRaces.Repositories.Entities
{
    public class DriverRepository : IRepository<IDriver>
    {
        private readonly IDictionary<string, IDriver> Models;
        public DriverRepository()
        {
            Models = new Dictionary<string, IDriver>();
        }
        public void Add(IDriver model)
        {
            Models.Add(model.Name, model);
        }

        public IReadOnlyCollection<IDriver> GetAll()
        {
            List<IDriver> returnCollection = new List<IDriver>();

            foreach (var item in Models)
            {
                returnCollection.Add(item.Value);
            }

            return returnCollection;
        }

        public IDriver GetByName(string name)
        {
            return Models[name];
        }

        public bool Remove(IDriver model)
        {
            if (Models.ContainsKey(model.Name)){
                Models.Remove(model.Name);
                return true;
            }
            return false;
        }
    }
}
