﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EasterRaces.Models.Cars.Contracts;
using EasterRaces.Models.Cars.Entities;
using EasterRaces.Models.Races.Entities;
using EasterRaces.Repositories.Contracts;

namespace EasterRaces.Repositories.Entities
{
    public class CarRepository : IRepository<ICar>
    {
        private readonly IDictionary<string, ICar> Models;
        public CarRepository()
        {
            Models = new Dictionary<string, ICar>();
        }
        public void Add(ICar model)
        {
            Models.Add(model.Model, model);
        }

        public IReadOnlyCollection<ICar> GetAll()
        {
            List<ICar> returnCollection = new List<ICar>();

            foreach (var item in Models)
            {
                returnCollection.Add(item.Value);
            }

            return returnCollection;
        }

        public ICar GetByName(string name)
        {
            return Models[name];
        }

        public bool Remove(ICar model)
        {
            if (Models.ContainsKey(model.Model)){
                Models.Remove(model.Model);
                return true;
            }
            return false;
        }
    }
}
