﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface ISearchable
    {
        string Search(string site);
    }
}
