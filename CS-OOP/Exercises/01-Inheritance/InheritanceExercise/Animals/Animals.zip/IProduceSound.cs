﻿public interface IProduceSound
{
    string ProduceSound();
}