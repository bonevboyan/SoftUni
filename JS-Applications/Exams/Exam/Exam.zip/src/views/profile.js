// import { getOwn } from '../api/data.js';
// import { html } from '../lib.js';
// import { getUserData } from '../util.js';

// //TODO
// const profileTemplate = (data, info) => html``;

// //TODO
// const card = (d) => html``;

// export async function showProfile(ctx) {
//     const userData = getUserData();
//     const data = await getOwn(userData.id);
//     ctx.render(profileTemplate(data, userData));
// }
